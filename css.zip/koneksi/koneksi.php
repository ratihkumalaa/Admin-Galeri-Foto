<?php
// Konfigurasi database
$host = "localhost"; // Ganti dengan host database Anda (default: localhost)
$user = "smksbico_selviyanti";      // Ganti dengan username database Anda
$pass = "Selvi2025!";          // Ganti dengan password database Anda
$db   = "smksbico_selviyanti";   // Nama database Anda (sesuai file .sql)

$conn = mysqli_connect($host, $user, $pass, $db);

// Periksa koneksi
if (!$conn) {
    die("Koneksi ke database gagal: " . mysqli_connect_error());
}
?>